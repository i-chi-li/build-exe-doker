
IntelOptimizationGuide
======================

Intels optimization guide can be downloaded from:

http://www.intel.com/content/www/us/en/processors/architectures-software-developer-manuals.html

----

Back to :doc:`AssemblerOptimizing <AssemblerOptimizing>`

$Date: 2014/10/27 22:04:54 $
