
AMDOptimizationGuide
====================

To many people this is considered the bible of Assembler optimizing.

The 'AMD64 Architecture Programmer's Manual Volume 1-5' can be
downloaded from the `Developer Guides & Manuals`_ section.

----

Back to :doc:`AssemblerOptimizing <AssemblerOptimizing>`

$Date: 2014/10/27 22:04:54 $

.. _Developer Guides & Manuals:
    http://developer.amd.com/resources/documentation-articles/developer-guides-manuals/
