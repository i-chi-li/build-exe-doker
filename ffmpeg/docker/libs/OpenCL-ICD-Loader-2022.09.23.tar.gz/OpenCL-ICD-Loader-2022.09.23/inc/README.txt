Copy or symlink OpenCL headers here, inside a CL directory, so that
the structure of the inc directory looks something like this:

inc/CL/cl_d3d10.h
inc/CL/cl_d3d11.h
inc/CL/cl_dx9_media_sharing.h
inc/CL/cl_egl.h
inc/CL/cl_ext.h
inc/CL/cl_gl.h
inc/CL/cl.h
inc/CL/cl.hpp
inc/CL/cl_platform.h
inc/CL/opencl.h
