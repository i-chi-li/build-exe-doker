
MMX
===

MMX is short for MultiMedia Extensions and was developed by Intel for Pentium MMX.

It contains a set of instructions that allows the programmers to operate on 8
bytes (64 bits) in 8 registers. AviSynth uses this technology to speed up
many of the internal filters.

Furthermore see :doc:`IntegerSSE <IntegerSSE>`.

Back to :doc:`AssemblerOptimizing`

$Date: 2014/10/27 22:04:54 $
