// OL_LightenImage was made common with OL_DarkenImage
